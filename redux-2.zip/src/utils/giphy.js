export const api_key = 's6iv3qb8HGC9kRtpZrnprMquECmn4dd0';
export const giphy_apis = {
  search: 'http://api.giphy.com/v1/gifs/search',
  trending: 'http://api.giphy.com/v1/gifs/trending' // api_key: string(required), limit: integer (int32), offset: integer (int32), rating: string, random_id: string
}