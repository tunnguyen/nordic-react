export default [
  {
    id: 'product1',
    img: require('../images/pro1.jpg'),
    name: 'Minimal decor furniture',
    category: 'Funiture',
    price: '100.000 VND'
  },
  {
    id: 'product2',
    img: require('../images/pro2.jpg'),
    name: 'Minimal decor furniture 2',
    category: 'Funiture',
    price: '100.000 VND'
  },
  {
    id: 'product3',
    img: require('../images/pro3.jpg'),
    name: 'Minimal decor furniture 3',
    category: 'Funiture',
    price: '100.000 VND'
  },
  {
    id: 'product4',
    img: require('../images/pro4.jpg'),
    name: 'Minimal decor furniture 4',
    category: 'Funiture',
    price: '100.000 VND'
  },
  {
    id: 'product5',
    img: require('../images/pro5.jpg'),
    name: 'Minimal decor furniture 5',
    category: 'Funiture',
    price: '100.000 VND'
  },
]