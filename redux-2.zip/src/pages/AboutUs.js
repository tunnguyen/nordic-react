import React from 'react';

const AboutUs = () => {
  return (
    <h2>About us</h2>
  )
}

export default AboutUs;